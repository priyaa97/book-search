<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'book' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'OP5a&wr;O>0t4oDfa]0OUSi)!7EEv3WBxVQSLABPiNn5WCGOgIw@JZ4)XdTb<_>D' );
define( 'SECURE_AUTH_KEY',  '9{$Z=pK[nUXpB}8%}Y>!o,CALq{ 25,=Y0eB>CgzT^3]qB/WUiM1siSnwxFnpJC(' );
define( 'LOGGED_IN_KEY',    '=TX|Y=(wqiy6HI(9b@w}CViFFZ4e2*yFAA<_h 1kF7QC)+CUeL@dpdRt)rOGazSv' );
define( 'NONCE_KEY',        'Z.,RP?eI:CZPx8j!pp+.7wAEz7sXV:6r3GVBC$Sp<h`hWP#X1)^r&b|yk,r0bJDy' );
define( 'AUTH_SALT',        'L(QRB Z)=p`y&=y-g&:qa7EqiK|EnhqnmQ?%TO#8zQ8-w(lpE iJF4 5JV[a!Qm6' );
define( 'SECURE_AUTH_SALT', '>OHBkpQ:5 Oe)G0]DkWm*Q0zp%bH%s0v}a@0R3U]$w1YcB3e7B6$X@yvnZ0&lBkd' );
define( 'LOGGED_IN_SALT',   'EDO|DB_&Gr4+.eX)G186{09nRoTU.H;PC%QwGC8^^9xd01-Qd;0J>(/k=AC5VoOy' );
define( 'NONCE_SALT',       'R{LXsS FO,#iw+Yxo{yG~m)]Ng(Z*/g{!^w<Z%@qjUot}42_]u`/vt-OiW(yF?15' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
